1. Upload all configs type .anom to folder "ren"
2. Run Rename.bat